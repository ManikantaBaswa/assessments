package com.streams.infoservices;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamExample {

	public static void main(String[] args) {
		List<String> l = Arrays.asList("maANi", "ravVi");
		List<String> value = l.stream().map(x -> x.toLowerCase()).collect(Collectors.toList());
		System.out.println(value);

	}

}
