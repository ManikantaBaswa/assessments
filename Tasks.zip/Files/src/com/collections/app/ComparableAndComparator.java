package com.collections.app;


import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ComparableAndComparator {

	public static void main(String[] args) {
//		List<Integer> l=new ArrayList<>();
		List<Integer> l1=Arrays.asList(11,67,89,42);
	Collections.sort(l1);
		System.out.println(l1);
		

	}

}
