package com.Employee.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EmpComparator implements Comparator<Employee> {

	public static void main(String[] args) {
		List<Employee> employees = new ArrayList<>();
		employees.add(new Employee(1, "Hari", 12345, 27));
		employees.add(new Employee(6, "stalin", 67890, 55));
		employees.add(new Employee(2, "ravi", 23456, 33));
		employees.add(new Employee(3, "karun", 34567, 37));
		employees.add(new Employee(4, "lucky", 45678, 45));
		employees.add(new Employee(5, "hitler", 56789, 48));
		Collections.sort(employees, new EmpComparator());

		for (Employee e : employees) {
			System.out.println(e.getName() + " - " + e.getSalary() + " - " + e.getAge());
		}
	}

	@Override
	public int compare(Employee e1, Employee e2) {
		int salaryCompared = Double.compare(e1.getSalary(), e2.getSalary());
		if (salaryCompared != 0) {
			return salaryCompared;
		}
		int nameCompared = e1.getName().compareTo(e2.getName());
		if (nameCompared != 0) {
			return nameCompared;
		}
		return Integer.compare(e2.getAge(), e1.getAge());

	}

}
