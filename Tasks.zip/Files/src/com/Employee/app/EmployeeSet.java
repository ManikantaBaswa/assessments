package com.Employee.app;

import java.util.TreeSet;

public class EmployeeSet {
	TreeSet<Employee> empTreeset = new TreeSet<>(new EmpComparator());

	public static void main(String[] args) {
		EmployeeSet employeeSet = new EmployeeSet();
		Employee emp1 = new Employee(1, "kiran", 12345, 28);
		Employee emp2 = new Employee(2, "chandu", 23456, 32);
		Employee emp3 = new Employee(3, "marris", 34567, 38);
		Employee emp4 = new Employee(4, "larry", 45678, 42);
		employeeSet.addEmployee(emp1);
		employeeSet.addEmployee(emp2);
		employeeSet.addEmployee(emp3);
		employeeSet.addEmployee(emp4);
		for (Employee e : employeeSet.getEmpTreeSet()) {
			System.out.println(e.getName() + " - " + e.getSalary() + " - " + e.getAge());
		}

	}

	public int addEmployee(Employee emp) {
		if (emp == null) {
			return 1;
		}

		try {
			empTreeset.add(emp);
			return 0;
		} catch (Exception e) {
			return 1;
		}
	}

	public TreeSet<Employee> getEmpTreeSet() {
		return empTreeset;
	}
}
