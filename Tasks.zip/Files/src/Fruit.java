import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Fruit {
	private String name;
	private int count;

	public Fruit(String name, int count) {
		super();
		this.name = name;
		this.count = count;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public void incrementCount() {
		this.count++;
	}

	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("Please provide the file path as a command line argument.");
			return;
		}

		String filePath = args[0];

		Map<String, Fruit> fruitMap = new HashMap<>();

		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line;
			while ((line = br.readLine()) != null) {
				line = line.trim();

				if (fruitMap.containsKey(line)) {

					fruitMap.get(line).incrementCount();
				} else {
					fruitMap.put(line, new Fruit(line, 1));
				}
			}
		} catch (IOException e) {
			System.out.println("An error occurred while reading the file: " + e.getMessage());
		}

		for (Fruit fruit : fruitMap.values()) {
			System.out.println(fruit);
		}
	}

}
