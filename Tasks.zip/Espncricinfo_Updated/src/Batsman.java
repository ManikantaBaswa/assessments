public class Batsman {
    private int id;
    private String name;
    private int runsScored;
    private int centuries;
    private int halfCenturies;

    public Batsman(int id, String name, int runsScored, int centuries, int halfCenturies) {
        this.id = id;
        this.name = name;
        this.runsScored = runsScored;
        this.centuries = centuries;
        this.halfCenturies = halfCenturies;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getRunsScored() {
        return runsScored;
    }

    public int getCenturies() {
        return centuries;
    }

    public int getHalfCenturies() {
        return halfCenturies;
    }

    public void updateStats(int centuries, int halfCenturies) {
        this.centuries += centuries;
        this.halfCenturies += halfCenturies;
    }
}
