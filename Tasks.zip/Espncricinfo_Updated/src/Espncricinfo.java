public class Espncricinfo {
    private static final int SIZE = 50;
    private Batsman[] batsmans; 
    private int noOfBatsmen; 

    public Espncricinfo() {
        this.batsmans = new Batsman[SIZE];
        this.noOfBatsmen = 0;
    }

    
    public Batsman[] getBatsmans() {
        return batsmans;
    }

    public int getNoOfBatsmen() {
        return noOfBatsmen;
    }

   
    public int addBatsman(String name, int runsScored, int centuries, int halfCenturies) {
        if (noOfBatsmen < SIZE - 1) {
            int id = noOfBatsmen; 
            batsmans[noOfBatsmen++] = new Batsman(id, name, runsScored, centuries, halfCenturies);
            return id;
        } else {
            return 0; 
        }
    }

    
    public Batsman updateBatsmanStats(int id, int centuries, int halfCenturies) {
        for (int i = 0; i < noOfBatsmen; i++) {
            if (batsmans[i].getId() == id) {
                batsmans[i].updateStats(centuries, halfCenturies);
                return batsmans[i];
            }
        }
        return null; }

    
    public Batsman getBatsman(int batsmanId) {
        for (int i = 0; i < noOfBatsmen; i++) {
            if (batsmans[i].getId() == batsmanId) {
                return batsmans[i];
            }
        }
        return null; 
    }
   
        public static void main(String[] args) {
            Espncricinfo espncricinfo = new Espncricinfo();

          
            int id1 = espncricinfo.addBatsman("Ravi", 5000, 10, 20);
            int id2 = espncricinfo.addBatsman("Hari", 3000, 5, 15);
            int id3 = espncricinfo.addBatsman("larry", 6000, 10, 20);
            int id4 = espncricinfo.addBatsman("marie", 70000, 5, 15);
            int id5 = espncricinfo.addBatsman("sunny", 8000, 10, 20);
            int id6 = espncricinfo.addBatsman("lucy", 90000, 5, 15);

          
            espncricinfo.updateBatsmanStats(id1, 3,3);

          
            Batsman batsman = espncricinfo.getBatsman(id1);
            if (batsman != null) {
                System.out.println("Batsman found: " + batsman.getName());
                System.out.println("Runs scored: " + batsman.getRunsScored());
                System.out.println("Centuries: " + batsman.getCenturies());
                System.out.println("Half centuries: " + batsman.getHalfCenturies());
            } else {
                System.out.println("Batsman not found.");
            }
        }
    }


