package com.assignment1;
public class Espncricinfo {
    private static final int SIZE = 50; // Constant size of batsmans array
    private Batsman[] batsmans; // Array to hold batsman objects
    private int noOfBatsmen; // Counter for number of batsmen


    // Constructor to initialize batsmans array and other attributes
    public Espncricinfo() {
        this.batsmans = new Batsman[SIZE];
        this.noOfBatsmen = 0;
    }

    // Method to get all batsmans
    public Batsman[] getBatsmans() {
        return batsmans;
    }

    // Method to get number of batsmen
    public int getNoOfBatsmen() {
        return noOfBatsmen;
    }
    
    // Method to add a new batsman
    public int addBatsman(String name, int runsScored, int centuries, int halfCenturies) {
        if (noOfBatsmen < SIZE - 1) {
            int id = noOfBatsmen; // Assigning ID based on current number of batsmen
            batsmans[noOfBatsmen++] = new Batsman(id, name, runsScored, centuries, halfCenturies);
            return id;
        } else {
            return 0; // Return 0 if batsmans array is full
        }
    }

    // Method to update batsman stats
    public Batsman updateBatsmanStats(int id, int centuries, int halfCenturies) {
        for (int i = 0; i < noOfBatsmen; i++) {
            if (batsmans[i].getId() == id) {
                batsmans[i].updateStats(centuries, halfCenturies);
                return batsmans[i];
            }
        }
        return null; // Return null if batsman with given ID not found
    }

    // Method to get batsman by ID
    public Batsman getBatsman(int batsmanId) {
        for (int i = 0; i < noOfBatsmen; i++) {
            if (batsmans[i].getId() == batsmanId) {
                return batsmans[i];
            }
        }
        return null; // Return null if batsman with given ID not found
    }
   
}
