
public class Main {
    public static void main(String[] args) {
        Espncricinfo espncricinfo = new Espncricinfo();

        // Adding batsmen
        int batsmanId1 = espncricinfo.addBatsman("Player1", 5000, 10, 20);
        int batsmanId2 = espncricinfo.addBatsman("Player2", 3000, 5, 15);

        // Updating batsman stats
        espncricinfo.updateBatsmanStats(batsmanId1, 2, 3);

        // Getting batsman by ID
        Batsman batsman = espncricinfo.getBatsman(batsmanId1);
        if (batsman != null) {
            System.out.println("Batsman found: " + batsman.getName());
            System.out.println("Runs scored: " + batsman.getRunsScored());
            System.out.println("Centuries: " + batsman.getCenturies());
            System.out.println("Half centuries: " + batsman.getHalfCenturies());
        } else {
            System.out.println("Batsman not found.");
        }
    }
}

}
